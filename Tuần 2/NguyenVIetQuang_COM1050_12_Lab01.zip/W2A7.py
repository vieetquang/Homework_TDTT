A = int((13 ** 2) * 3)
B = int(13**2*3 + 5)
print(A , B)
