a = input("Số a: ")
b = input("Số b: ")
a , b = b , a
print("Số a:", a , "Số b:", b)