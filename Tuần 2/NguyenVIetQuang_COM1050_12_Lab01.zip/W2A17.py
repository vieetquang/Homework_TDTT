print("  *  ")
print(" *** ")
print("*****")