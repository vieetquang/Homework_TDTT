DoC = float(input("Nhap Do C:"))
DoF = DoC * 9/5 +32
print("Do F la:", round(DoF, 2))