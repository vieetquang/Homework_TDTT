a = "Hello, World!"
for i in range(10):
    print(a)