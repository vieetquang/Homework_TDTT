A = int(input("Số A: "))
B = int(input("Số B: "))
print("Hàng đơn vị của A nhân B: ", str(A*B)[-1], "; Kết quả A nhân B: ", A*B)