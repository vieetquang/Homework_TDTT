gio = int(input("Nhập giờ:"))
phut = int(input("Nhập phút:"))
convert = (gio * 60 + phut)*60
print("Tổng số Giây:", convert)