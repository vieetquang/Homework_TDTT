cost = int(input("Giá sản phẩm (USD):"))
print("Tổng tiền phải trả:", cost*1.4 + 10, "USD")