soa = float(input("so a?"))
sob = float(input("so b?"))
somu = soa ** sob
print("a^b =", somu)