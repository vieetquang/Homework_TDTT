seasons = ["Spring", "Summer", "Autumn", "Winter"]
for i in seasons:
    print(i)